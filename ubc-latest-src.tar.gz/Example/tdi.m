const tdi <- object tdi
  initially
    var x : Integer 
    x <- 56
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    x <- 67
  end initially
end tdi
