% This file has a character with the meta bit on in a comment,
% right here: �
const funnychar <- object funnychar
  % also in an indentifier, right here
  const this�id <- 45
end funnychar
