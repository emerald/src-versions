const foobar <- object foobar
  operation Think 
    
  end Think
  operation Eat 
    
  end Eat
  process
    self.Think[]
    self.Eat
  end process
end foobar
