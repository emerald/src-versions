const a <- 45
const b <- 'd'
const c <- false
const d <- true
const e <- immutable object e
  
end e
const f <- "abc"

export a,b,c,d,e,f
