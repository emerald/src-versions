const tfor <- object tfor
  initially
    for i : Integer <- 0 while i < 10 or i < 10 by i <- i + 1
    end for
  end initially
end tfor
