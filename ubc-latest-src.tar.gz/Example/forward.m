const in1 <- Vector.of[In1type].create[10]
const in2 <- Vector.of[In2type].create[10]

const in1type <- Integer
const in2type <- Real

