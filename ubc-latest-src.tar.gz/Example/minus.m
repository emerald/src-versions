const minus <- object minus
  initially
    var x : Integer <- ~1
    stdout.putint[x, 0]
    stdout.putstring["\n"]
  end initially
end minus
