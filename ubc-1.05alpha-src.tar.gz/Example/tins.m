const foo <- object foo
  initially
    self.doit[stdin]
  end initially
  operation doit [a : Any]
  end doit
end foo
