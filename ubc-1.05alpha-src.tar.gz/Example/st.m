const st <- immutable object st
  export function of[a : Type] -> [r : Any]
    forall a
    suchthat a *> typeobject t end t
    suchthat a *> typeobject u end u
  end of
end st
