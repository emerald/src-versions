const tfoo <- object tfoo
  initially
    stdout.putint[1, 2]
    stdout.putchar['\n']
  end initially
end tfoo
