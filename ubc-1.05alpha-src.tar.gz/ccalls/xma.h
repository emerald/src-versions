/*
 * xma
 */

#if !defined(CCALL)
#define CCALL(func, subcode, argstring) 
#endif /* CCALL */
